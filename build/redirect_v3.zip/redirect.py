import json

def lambda_handler(event, context):   
    response = {}
    raise Exception('Python error!')
    return response